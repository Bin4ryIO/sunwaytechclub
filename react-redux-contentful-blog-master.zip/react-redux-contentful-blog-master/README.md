###Getting Started####
Checkout this repo, install dependencies, then start the server with the following:

```
	> git clone git@github.com:avishekjana/react-redux-contentful-blog.git
	> cd react-redux-contentful-blog
	> npm install
	> npm start
```
